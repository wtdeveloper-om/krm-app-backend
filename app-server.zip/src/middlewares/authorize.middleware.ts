import { Request, Response, NextFunction } from "express";

export const requireRole = (...roles: Array<"USER" | "DOCTOR">) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.body.user) {
      return res.status(401).json({ message: "Unauthenticated" });
    }

    if (!roles.includes(req.body.user.role)) {
      return res.status(403).json({ message: "Forbidden" });
    }

    next();
  };
};