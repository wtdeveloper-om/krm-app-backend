import { prisma } from "../../config/db";

export const getVideoService = async () => {
    try {
        const video = await prisma.video.findMany();

        if(!video) {
            return null;
        }

        return video;
    } catch (error) {
        console.error(error);
        return null;
    }
};

export const getVideoServiceById = async (id: string) => {
    try {
        const video = await prisma.video.findUnique({
            where: {
                id,
            },
        });

        if(!video) {
            return null;
        }

        return video;
    } catch (error) {
        console.error(error);
        return null;
    }
};

export const getReelService = async () => {
    try {
        const reel = await prisma.reel.findMany();

        if(!reel) {
            return null;
        }

        return reel;
    } catch (error) {
        console.error(error);
        return null;
    }
};

export const getReelServiceById = async (id: string) => {
    try {
        const reel = await prisma.reel.findUnique({
            where: {
                id,
            },
        });

        if(!reel) {
            return null;
        }

        return reel;
    } catch (error) {
        console.error(error);
        return null;
    }
};

export const getBlogService = async () => {
    try {
        const blog = await prisma.blog.findMany();

        if(!blog) {
            return null;
        }

        return blog;
    } catch (error) {
        console.error(error);
        return null;
    }
};

export const getBlogServiceById = async (id: string) => {
    try {
        const blog = await prisma.blog.findUnique({
            where: {
                id,
            },
        });

        if(!blog) {
            return null;
        }

        return blog;
    } catch (error) {
        console.error(error);
        return null;
    }
};

export const getRecipeService = async () => {
    try {
        const recipe = await prisma.recipe.findMany();

        if(!recipe) {
            return null;
        }

        return recipe;
    } catch (error) {
        console.error(error);
        return null;
    }
};

export const getRecipeServiceById = async (id: string) => {
    try {
        const recipe = await prisma.recipe.findUnique({
            where: {
                id,
            },
        });

        if(!recipe) {
            return null;
        }

        return recipe;
    } catch (error) {
        console.error(error);
        return null;
    }
};
