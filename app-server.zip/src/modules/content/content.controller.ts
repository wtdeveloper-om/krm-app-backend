import { Request, Response } from "express";
import { getVideoService } from "./content.service";

export const getVideoController = async (req: Request, res: Response) => {
    try {
        const video = await getVideoService();

        if(!video) {
            return res.status(400).json({ message: "Failed to get video" });
        }

        return res.status(200).json({ video });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "Internal server error" });
    }
};

export const getVideoControllerById = async (req: Request, res: Response) => {
    try {
        const video = await getVideoServiceById(req.params.id);

        if(!video) {
            return res.status(400).json({ message: "Failed to get video" });
        }

        return res.status(200).json({ video });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "Internal server error" });
    }
};

export const getReelController = async (req: Request, res: Response) => {
    try {
        const reel = await getReelService();

        if(!reel) {
            return res.status(400).json({ message: "Failed to get reel" });
        }

        return res.status(200).json({ reel });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "Internal server error" });
    }
};

export const getReelControllerById = async (req: Request, res: Response) => {
    try {
        const reel = await getReelServiceById(req.params.id);

        if(!reel) {
            return res.status(400).json({ message: "Failed to get reel" });
        }

        return res.status(200).json({ reel });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "Internal server error" });
    }
};
