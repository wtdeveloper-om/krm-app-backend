import { Router } from "express";

const router = Router();

router.get("/content/video", getVideoController);
router.get("/content/video/:id", getVideoControllerById);
router.get("/content/reel", getReelController);
router.get("/content/reel/:id", getReelControllerById);
router.get("/content/blog", getBlogController);
router.get("/content/blog/:id", getBlogControllerById);
router.get("/content/recipe", getRecipeController);
router.get("/content/recipe/:id", getRecipeControllerById);

export default router;
