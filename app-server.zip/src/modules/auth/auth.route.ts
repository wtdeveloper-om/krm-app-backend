import { Router } from "express";
import { googleAuthController, verifyOtpController } from "./auth.controller";

const router = Router();

router.post("/google", googleAuthController);
router.post("/verify-otp", verifyOtpController);
// router.post("/refresh-token", refreshTokenController);

export default router;
