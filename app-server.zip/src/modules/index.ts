import authRoute from "./auth/auth.route";
import diseaseRoute from "./disease/disease.route";

export { authRoute, diseaseRoute };