import { Router } from "express";

const router = Router();

router.get("/disease", );
router.get("/disease/:id", );
router.put("/disease/:id", );
router.delete("/disease/:id", );

export default router;