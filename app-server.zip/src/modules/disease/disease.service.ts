import { prisma } from "../../config/db";

export const createDiseaseService = async (diseaseData: any) => {
    try {
        const disease = await prisma.disease.create({
            data: diseaseData,
        });

        return disease;
    } catch (error) {
        console.error(error);
        return null;
    }
};