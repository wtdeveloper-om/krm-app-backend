import { Request, Response } from "express";
import { createDiseaseService } from "./disease.service";


export const getAllDiseaseController = async (req: Request, res: Response) => {
    try {
        const disease = await getAllDiseaseService();

        if(!disease) {
            return res.status(400).json({ message: "Failed to get all diseases" });
        }

        return res.status(200).json({ disease });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "Internal server error" });
    }
};

export const createDiseaseController = async (req: Request, res: Response) => {
    try {
        const disease = await createDiseaseService(req.body);

        if(!disease) {
            return res.status(400).json({ message: "Failed to create disease" });
        }

        return res.status(201).json({ disease });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "Internal server error" });
    }
};

export const getDiseaseController = async (req: Request, res: Response) => {
    try {
        const disease = await getDiseaseService(req.params.id);

        if(!disease) {
            return res.status(400).json({ message: "Failed to get disease" });
        }

        return res.status(200).json({ disease });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "Internal server error" });
    }
};

export const updateDiseaseController = async (req: Request, res: Response) => {
    try {
        const disease = await updateDiseaseService(req.params.id, req.body);

        if(!disease) {
            return res.status(400).json({ message: "Failed to update disease" });
        }

        return res.status(200).json({ disease });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "Internal server error" });
    }
};

export const deleteDiseaseController = async (req: Request, res: Response) => {
    try {
        const disease = await deleteDiseaseService(req.params.id);

        if(!disease) {
            return res.status(400).json({ message: "Failed to delete disease" });
        }

        return res.status(200).json({ disease });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "Internal server error" });
    }
};